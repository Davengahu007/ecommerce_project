<!DOCTYPE html>
 <html>
  <head>
   <title>Admin Sign in</title>
   <link rel = "stylesheet" href="Volkra_Signin.css">
  </head>

<body>
<img src="VK-emblem2.png" class="center">
<h1 class = "Welcome_Statement">WELCOME BACK ADMIN</h1>

<div class = "container">
  <div class = "Title">Kindly enter your details below to sign in</div>
    <form action = "#">
      <div class = "User_Signin_details">

        <div class = "input-box">
          <span class=  "details"> Admin Username </span>
          <input type = "text" placeholder = "Enter your name" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Password </span>
          <input type = "text" placeholder = "Enter your password" required>
        </div>


      <div class = "button">
        <input type = "submit" value = "Sign In">
      </div>
      </div>
    </form>
  </div>

  </div>
</body>
</html>
