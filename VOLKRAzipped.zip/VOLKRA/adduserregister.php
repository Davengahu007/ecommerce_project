<?php
print_r($_POST);
require("connect.php");


$user_id = $_POST["userid"];
$first_name = $_POST["firstname"];
$last_name = $_POST["lastname"];
$email = $_POST["email"];
$password = $_POST["password"];
$gender = $_POST["gender"];
$role = $_POST["role"];


$sql = "INSERT INTO VOLKRA.users (user_id, firstname, surname, email, password, gender , role) VALUES ('$user_id' , '$first_name' , '$last_name' , '$email' , 'password', 'gender' , 'role')";

if(mysqli_query($conn,$sql)){
  echo "New record created successfully";

}
    else
    {
      echo "Error:" . $sql . "<br>" .$conn -> error;
    }


    mysqli_query($conn,$sql);
?>
