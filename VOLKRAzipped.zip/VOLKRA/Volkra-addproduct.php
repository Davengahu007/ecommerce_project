<!DOCTYPE html>
 <html>
  <head>
   <title>Add product</title>
   <link rel = "stylesheet" href="Volkra-addproduct.css">
  </head>

<body>
<img src="VK-emblem2.png" class="center">
<h1 class = "Welcome_Statement">WELCOME TO VOLKRA</h1>

<div class = "container">
  <div class = "Title">Enter details about the new product</div>
    <form action = "addproductregister.php" method = "post">
      <div class = "product_details">

        <div class = "input-box">
          <span class=  "details"> Product Name </span>
          <input type = "text" name = "productname" placeholder = "Enter Product name" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Product ID </span>
          <input type = "number" name = "productid" placeholder = "Enter product ID" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Product Description </span>
          <input type = "text" name = "productdescription" placeholder = "Enter the product description" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Product image </span>
          <input type = "text" name = "productimage" placeholder = "Insert an image of the product">
        </div>

        <div class = "input-box">
          <span class=  "details"> Date Created </span>
          <input type = "date" name = "datecreated" placeholder = "Enter the date it was created" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Date Updated </span>
          <input type = "date" name = "dateupdated" placeholder = "Enter the date it was updated" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Unit Price </span>
          <input type = "number" name = "unitprice" placeholder = "Enter the unit price of the product" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Quantity available </span>
          <input type = "number" name = "quantityavailable" placeholder = "Enter the quantity available" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Sub Category ID </span>
          <input type = "number" name = "subcategoryid" placeholder = "Enter the sub category id of the product" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Added by </span>
          <input type = "number" name = "addedby" placeholder = "Enter the id of the person who added the product" required>
        </div>

      <div class = "button">
      <input type = "submit" value = "Add Category">
      </div>
      </div>

  </div>
  </form>



</body>
</html>
