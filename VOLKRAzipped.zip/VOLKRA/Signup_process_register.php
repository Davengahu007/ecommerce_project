<?php
print_r($_POST);
require("connect.php");


$user_name = $_POST["name"];
$new_pass = $_POST["pass"];
$confirm_pass = $_POST["confirm"];
$answer = $_POST["answer"];


$sql = "INSERT INTO VOLKRA.user_details (Username, NewPass, ConfirmPass, Answer) VALUES ('$user_name' , '$new_pass' , '$confirm_pass' , '$answer')";

if(mysqli_query($conn,$sql)){
  echo "New record created successfully";

}
    else
    {
      echo "Error:" . $sql . "<br>" .$conn -> error;
    }


    mysqli_query($conn,$sql);
?>
