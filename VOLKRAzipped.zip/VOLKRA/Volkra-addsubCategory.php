<!DOCTYPE html>
 <html>
  <head>
   <title>Sign up</title>
   <link rel = "stylesheet" href="Volkra-addsubCategory.css">
  </head>

<body>
<img src="VK-emblem2.png" class="center">
<h1 class = "Welcome_Statement">WELCOME TO VOLKRA</h1>

<div class = "container">
  <div class = "Title">Enter details about the new sub category</div>
    <form action = "addsubcategoryregister.php" method = "post">
      <div class = "subcategory_details">

        <div class = "input-box">
          <span class=  "details"> Sub-Category Name </span>
          <input type = "text" name = "subcategoryname" placeholder = "Enter Sub Category name" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Sub Category ID </span>
          <input type = "text" name = "subcategoryid" placeholder = "Enter Sub Category ID" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Category Name </span>
          <input type = "text" name = "categoryname" placeholder = "Enter category in which it is" required>
        </div>

      <div class = "button">
      <input type = "submit" value = "Add Sub Category">
      </div>
      </div>

  </div>
  </form>



</body>
</html>
