<?php
print_r($_POST);
require("connect.php");


$category_names = $_POST["categoryname"];
$category_id = $_POST["categoryid"];


$sql = "INSERT INTO VOLKRA.category (Category_name, Category_ID) VALUES ('$category_names' , '$category_id')";

if(mysqli_query($conn,$sql)){
  echo "New record created successfully";

}
    else
    {
      echo "Error:" . $sql . "<br>" .$conn -> error;
    }


    mysqli_query($conn,$sql);
?>
