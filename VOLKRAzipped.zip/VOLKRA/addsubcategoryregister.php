<?php
print_r($_POST);
require("connect.php");


$subcategory_name = $_POST["subcategoryname"];
$subcategory_id = $_POST["subcategoryid"];
$category_name = $_POST["categoryname"];



$sql = "INSERT INTO VOLKRA.sub_category (Subcategory_name, Subcategory_id, Category_name) VALUES ('$subcategory_name' , '$subcategory_id' , '$category_name')";

if(mysqli_query($conn,$sql)){
  echo "New record created successfully";

}
    else
    {
      echo "Error:" . $sql . "<br>" .$conn -> error;
    }


    mysqli_query($conn,$sql);
?>
