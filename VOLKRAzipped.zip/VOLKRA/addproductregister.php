<?php
print_r($_POST);
require("connect.php");


$product_name = $_POST["productname"];
$product_id = $_POST["productid"];
$product_description = $_POST["productdescription"];
$product_image = $_POST["productimage"];
$date_created = $_POST["productcreated"];
$date_updated = $_POST["productupdated"];
$unit_price = $_POST["unitprice"];
$quantity_available = $_POST["quantityavailable"];
$subcategory_id = $_POST["subcategoryid"];
$added_by = $_POST["addedby"];



$sql = "INSERT INTO VOLKRA.products (product_id, product_name, product_description, product_image, unit_price , available_quantity , sub_category_id ,created_at , updated_at , added_by)
 VALUES ('$product_name' , '$product_id' , '$product_description' , '$product_image' , '$date_created' , '$date_updated' , '$unit_price' , '$quantity_available' , '$subcategory_id' , '$added_by')";

if(mysqli_query($conn,$sql)){
  echo "New record created successfully";

}
    else
    {
      echo "Error:" . $sql . "<br>" .$conn -> error;
    }


    mysqli_query($conn,$sql);
?>
