<!DOCTYPE html>
 <html>
  <head>
   <title>Sign in</title>
   <link rel = "stylesheet" href="Volkra_Signin.css">
  </head>

<body>
<img src="VK-emblem2.png" class="center">
<h1 class = "Welcome_Statement">WELCOME TO VOLKRA</h1>

<div class = "container">
  <div class = "Title">Kindly enter your details below to sign in</div>
    <form action = "#">
      <div class = "User_Signin_details">

        <div class = "input-box">
          <span class=  "details"> Username </span>
          <input type = "text" placeholder = "Enter your name" required>
        </div>

        <div class = "input-box">
          <span class=  "details"> Password </span>
          <input type = "text" placeholder = "Enter your password" required>
        </div>

     <p class = "No_account"> Do not have an account? <a href="http://localhost/ecommerce_project/VOLKRA/Volkra_Signup.php"> Sign up </a> </p>




      <div class = "button">
        <input type = "submit" value = "Sign In">
      </div>
      </div>
    </form>
  </div>

  </div>
</body>
</html>
